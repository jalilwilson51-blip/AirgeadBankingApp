#include "InvestmentCalculator.h"
#include <iostream>
#include <iomanip>
using namespace std;

void InvestmentCalculator::getUserInput() {
    cout << "\n============================================\n";
    cout << "= Airgead Banking Investment Calculator     =\n";
    cout << "============================================\n";

    cout << "Enter Initial Investment Amount: $";
    cin >> m_initialInvestment;

    cout << "Enter Monthly Deposit: $";
    cin >> m_monthlyDeposit;

    cout << "Enter Annual Interest Rate (e.g., 5 for 5%): ";
    cin >> m_annualInterestRate;

    cout << "Enter Number of Years: ";
    cin >> m_numYears;
}

void InvestmentCalculator::displayInputSummary() const {
    cout << "\n============================================\n";
    cout << "= Investment Details Entered               =\n";
    cout << "============================================\n";
    cout << fixed << setprecision(2);
    cout << "Initial Investment Amount: $" << m_initialInvestment << endl;
    cout << "Monthly Deposit: $" << m_monthlyDeposit << endl;
    cout << "Annual Interest Rate: " << m_annualInterestRate << "%" << endl;
    cout << "Investment Duration: " << m_numYears << " years" << endl;
    cout << "\nPress any key to continue...";
    cin.ignore();
    cin.get();
}

void InvestmentCalculator::calculateWithoutMonthlyDeposit() {
    m_yearEndBalancesNoDeposit.clear();
    m_yearEndInterestsNoDeposit.clear();

    double yearEndBalance = m_initialInvestment;

    for (int year = 1; year <= m_numYears; ++year) {
        double interestEarned = 0.0;
        for (int month = 1; month <= 12; ++month) {
            double monthlyInterest = yearEndBalance * (m_annualInterestRate / 100.0) / 12.0;
            interestEarned += monthlyInterest;
            yearEndBalance += monthlyInterest;
        }
        m_yearEndInterestsNoDeposit.push_back(interestEarned);
        m_yearEndBalancesNoDeposit.push_back(yearEndBalance);
    }
}

void InvestmentCalculator::calculateWithMonthlyDeposit() {
    m_yearEndBalancesWithDeposit.clear();
    m_yearEndInterestsWithDeposit.clear();

    double balance = m_initialInvestment;

    for (int year = 1; year <= m_numYears; ++year) {
        double interestEarned = 0.0;
        for (int month = 1; month <= 12; ++month) {
            balance += m_monthlyDeposit;
            double monthlyInterest = balance * (m_annualInterestRate / 100.0) / 12.0;
            interestEarned += monthlyInterest;
            balance += monthlyInterest;
        }
        m_yearEndInterestsWithDeposit.push_back(interestEarned);
        m_yearEndBalancesWithDeposit.push_back(balance);
    }
}

void InvestmentCalculator::displayYearlyReport(bool withDeposits) const {
    cout << "\n============================================\n";
    cout << (withDeposits ? "= Report: With Monthly Deposits            =\n"
                          : "= Report: Without Monthly Deposits         =\n");
    cout << "============================================\n";
    cout << left << setw(10) << "Year" << setw(20) << "Year End Balance" << "Year End Earned Interest" << endl;
    cout << "--------------------------------------------------------\n";
    cout << fixed << setprecision(2);

    const vector<double>& balances = withDeposits ? m_yearEndBalancesWithDeposit : m_yearEndBalancesNoDeposit;
    const vector<double>& interests = withDeposits ? m_yearEndInterestsWithDeposit : m_yearEndInterestsNoDeposit;

    for (size_t i = 0; i < balances.size(); ++i) {
        cout << left << setw(10) << (i + 1) << "$" << setw(19) << balances[i] << "$" << interests[i] << endl;
    }
}
