#ifndef AIRGEAD_BANKING_INVESTMENTCALCULATOR_H_
#define AIRGEAD_BANKING_INVESTMENTCALCULATOR_H_

#include <vector>
#include <string>

class InvestmentCalculator {
public:
    void getUserInput();
    void displayInputSummary() const;
    void calculateWithoutMonthlyDeposit();
    void calculateWithMonthlyDeposit();
    void displayYearlyReport(bool withDeposits) const;

private:
    double m_initialInvestment;
    double m_monthlyDeposit;
    double m_annualInterestRate;
    int m_numYears;

    std::vector<double> m_yearEndBalancesNoDeposit;
    std::vector<double> m_yearEndInterestsNoDeposit;
    std::vector<double> m_yearEndBalancesWithDeposit;
    std::vector<double> m_yearEndInterestsWithDeposit;
};

#endif  // AIRGEAD_BANKING_INVESTMENTCALCULATOR_H_
