#include "InvestmentCalculator.h"
#include <iostream>
#include <limits>
using namespace std;

int main() {
    char runAgain = 'y';

    while (tolower(runAgain) == 'y') {
        InvestmentCalculator investmentCalc;

        investmentCalc.getUserInput();
        investmentCalc.displayInputSummary();

        investmentCalc.calculateWithoutMonthlyDeposit();
        investmentCalc.displayYearlyReport(false);

        investmentCalc.calculateWithMonthlyDeposit();
        investmentCalc.displayYearlyReport(true);

        cout << "\nWould you like to test another scenario? (y/n): ";
        cin >> runAgain;
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
    }

    cout << "\nThank you for using the Airgead Banking Investment Calculator. Goodbye!\n";
    return 0;
}
